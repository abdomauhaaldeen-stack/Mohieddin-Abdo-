package com.mohieddin.artgallery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class Artwork(
    val title: String,
    val category: String,
    val image: Int
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GalleryApp() }
    }
}

@Composable
fun GalleryApp() {
    var selected by remember { mutableStateOf("All") }
    var selectedArtwork by remember { mutableStateOf<Artwork?>(null) }
    val categories = listOf("All", "Anime", "Manga", "Portrait", "Digital")

    val artworks = listOf(
        Artwork(
            title = "Anime Portrait — White Cap",
            category = "Anime",
            image = R.drawable.artwork_01
        ),
        Artwork(
            title = "Blue-Eyed Portrait",
            category = "Portrait",
            image = R.drawable.artwork_02
        ),
        Artwork(
            title = "Colorful Rooster",
            category = "Digital",
            image = R.drawable.artwork_03
        )
    )

    if (selectedArtwork != null) {
        ArtworkDetails(selectedArtwork!!) { selectedArtwork = null }
        return
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = {
                Column(
                    Modifier.fillMaxWidth()
                        .background(Color(0xFF0E0E0E))
                        .padding(horizontal = 20.dp, vertical = 18.dp)
                ) {
                    Text(
                        "MOHIEDDIN ART",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Digital Art • Anime • Manga • Portrait",
                        color = Color.LightGray
                    )
                }
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = true, onClick = {},
                        icon = { Text("⌂") }, label = { Text("Gallery") }
                    )
                    NavigationBarItem(
                        selected = false, onClick = {},
                        icon = { Text("♡") }, label = { Text("Favorites") }
                    )
                    NavigationBarItem(
                        selected = false, onClick = {},
                        icon = { Text("i") }, label = { Text("About") }
                    )
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(16.dp)
            ) {
                Text(
                    "My Works",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = selected == cat,
                            onClick = { selected = cat },
                            label = { Text(cat) }
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))

                val filtered = if (selected == "All")
                    artworks else artworks.filter { it.category == selected }

                LazyVerticalGrid(
                    columns = GridCells.Fixed(1),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(filtered) { art ->
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedArtwork = art }
                        ) {
                            Column {
                                Image(
                                    painter = painterResource(art.image),
                                    contentDescription = art.title,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(430.dp)
                                        .clip(RoundedCornerShape(20.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                Column(Modifier.padding(16.dp)) {
                                    Text(art.title, fontWeight = FontWeight.Bold)
                                    Text(art.category, color = Color.Gray)
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        "Artwork by Mohieddin Abdo",
                                        color = Color.LightGray
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ArtworkDetails(art: Artwork, onBack: () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onBack) { Text("← Back") }
                    Text(
                        "Artwork",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(16.dp)
            ) {
                Image(
                    painter = painterResource(art.image),
                    contentDescription = art.title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(560.dp)
                        .clip(RoundedCornerShape(22.dp)),
                    contentScale = ContentScale.Fit
                )
                Spacer(Modifier.height(18.dp))
                Text(art.title, style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold)
                Text(art.category, color = Color.Gray)
                Spacer(Modifier.height(12.dp))
                Text("Created by Mohieddin Abdo")
                Spacer(Modifier.height(18.dp))
                Button(onClick = {}) { Text("♡ Add to Favorites") }
            }
        }
    }
}
